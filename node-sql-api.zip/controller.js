'use strict';
var dbConn = require('./../../config/db.config');

const User = require('../user.model');

exports.findAll = function(req, res) {
  User.findAll(function(err, user) {
    console.log('controller')
    if (err)
    res.send(err);
    console.log('res', user);
    res.send(user);
  });

    mysqlConnection.query('SELECT * FROM User', (err, rows, fields) => {
        if (!err)
            return res.send(rows);
        else
            return console.log(err);
    })
  });
};