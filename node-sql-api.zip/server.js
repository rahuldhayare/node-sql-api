const mysql = require('mysql');
const express = require('express');
const bodyparser = require('body-parser');
var cors = require('cors')
const path = require('path');
const exphbs = require('express-handlebars');

var app = express();

app.use(bodyparser.json());
app.use(cors())
app.use(express.urlencoded({ extended: false }));
app.use(bodyparser.json({ type: 'application/*+json' }));

app.engine('hbs', exphbs({
    defaultLayout: 'main',
    extname: '.hbs'
}));

app.set('view engine', 'hbs');

var mysqlConnection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'cards',
    multipleStatements: true
});

mysqlConnection.connect((err) => {
    if (!err)
        console.log('DB connection succeded.');
    else
        console.log('DB connection failed \n Error : ' + JSON.stringify(err, undefined, 2));
});


// card number masking
app.get('/mask_card/', cardno); 
function cardno(req, res) {
    var card_no = req.query.card_no;
    if(card_no.length > 13 && card_no.length < 19) {
        str = card_no.replace(/(\+?\d{5})(\d+)(\d{5})/g, function(match, start, middle, end) {
            return start + "X".repeat(middle.length) + end;
          });
        res.json(str) 
    } else {
        return res.json('invalid card number') 
    }
}

//Get all Users
app.get('/user', (req, res) => {
    mysqlConnection.query('SELECT * FROM User', (err, rows, fields) => {
        if (!err)
            return res.send(rows);
        else
            return console.log(err);
    })
});

//Get an Users
app.get('/user/:id', (req, res) => {
    mysqlConnection.query('SELECT * FROM User WHERE userid = ?', [req.params.id], (err, rows, fields) => {
        if (!err)
            return res.send(rows);
        else
            return console.log(err);
    })
});

// userlogin
app.post('/login', (req, res) => {
    var email= req.body.email;
    var pass = req.body.password;
    mysqlConnection.query('SELECT * FROM user WHERE email = ?',[email],  function (error, results, fields) {
      if (error) {
        return res.send({
          "code":400,
          "failed":"error ocurred"
        })
      }else{
        if(results.length >0){
            var n = pass.localeCompare(results[0].password);
            if(n == 0) {
                return  res.send({
                    "code":200,
                    "success":"login sucessfull",
                    "user":results[0]
                  })
            }
            else {
                return res.send({
                     "code":204,
                     "failure":"Email and password does not match"
                })
              }
        }
        else{
            return res.send({
            "code":206,
            "success":"Email does not exits"
              });
        }
      }
      });
});

//user logout
app.post('/logout',  (req, res) => {
    var email= req.body.email;
    mysqlConnection.query('SELECT * FROM user WHERE email = ?',[email], async function (error, results, fields) {
      if (error) {
        return res.send({
          "code":400,
          "failed":"error ocurred"
        })
      } else{
        if(results.length >0){
            return res.send({
                "code":200,
                "success":"logout successful"
              })
        }
        else{
            return res.send({
            "code":206,
            "Failure":"Error occured during logout"
              });
        }
      }
      });
});

//Delete an Users
app.delete('/Users/:id', (req, res) => {
    mysqlConnection.query('DELETE FROM User WHERE userid = ?', [req.params.id], (err, rows, fields) => {
        if (!err) {
           return res.send({
                "code":200,
                "success":"Deleted successfully."
              })
        }
        else
            console.log(err);
            return res.send({
                "code":204,
                "failure":"Deleted operation failed"
           })
    })
});

//Insert an Users
app.post('/adduser', (req, res) => {
    let user = req.body;
    var sql = "SET @userid = ?;SET @name = ?;SET @email = ?;SET @password = ?; \
    CALL userAddOrEdit(@userid,@name,@email,@password);";
    mysqlConnection.query(sql, [user.userid, user.name, user.email,user.password], (err, rows, fields) => {
    if (!err) {
        rows.forEach(element => {
            if(element.constructor == Array)
            return res.send({
                "code":200,
                "success":"Registration successful New USER ID: "+ element[0].userid
            });
            });
    }
   
    else {
        console.log(err);
        return res.send({
             "code":204,
             "success":"Error during registering new user"
         });
    }
    })
});

//Update an user
app.put('/edituser', (req, res) => {
        let user = req.body;
    
        var sql = "SET @userid = ?;SET @name = ?;SET @email = ?;SET @password = ?; \
        CALL userAddOrEdit(@userid,@name,@email,@password);";
        mysqlConnection.query(sql, [user.userid, user.name, user.email, user.password], (err, rows, fields) => {
        if (!err)
        rows.forEach(element => {
        if(element.constructor == Array)
        return res.send({
            "code":200,
            "success":"Edited user successfully, New USER ID : "+ element[0].userid
        });
        });
        else
            return console.log(err);
        })
});

//view rendering
        app.get('/', (req, res) => {
            res.render('home');
        });

        app.get('/login-template', (req, res) => {
            res.render('login');
        });

        app.get('/register-template', (req, res) => {
            res.render('register');
        });

        app.get('/user-template', (req, res) => {
            res.render('userlist');
        });


app.listen(3000, () => console.log('Express server is runnig at port no : 3000'));
